use bangaloreaug;-- ctrl+enter
show tables;
show databases;
-- sakila sys 
/*
System data base/data dictinaries
information_schema
mysql
performance_schema
sys
============
Sakila human dummy 
db practice
*/
-- 9910453640 rahul IT
#############################
-- DDL
-- MUST CREATE (table name,
-- column name,data types)
-- Optional(Constraints/rules) 
-- Number Datatypes
-- int unsigned/float,double,decimal
-- 3 / 3.0
create table t1(sno int,
rollno decimal,col3 float);
describe t1;
insert into t1 values
(1,2,3);-- 1,2.0,3.0
insert into t1 values
(-39,2.56,3.4747);
select * from t1;
create table t2
(sno int unsigned);
desc t2;
insert into t2 values
(-1);
select * from t2;
-- Inclass/Takehome
##############################
-- String Datatypes
-- a='Namrata'
-- CHAR,VARCHAR,text,tinytext
-- VARCHAR2 not MySQL
-- char is fixed length
-- varchar variable character length
create table t3 
(fname char,lastname 
varchar(2)); 
desc t3;
insert into t3 values
('n','ss');
-- char(10)'Namrata___'
-- varchar(10)'Namrata'
-- Name varchar(100)
-- empid char(5)
-- Char is faster than 
-- varchar
-- Date datatype
-- default format of date
-- 'yyyy-mm-dd' Must
-- dd-mm-yyyy functions
-- '2020-11-02'
create table t4 
(dob date);
insert into t4 values
('2019-11-02');
select * from t4;
create table final_table
(Sid int unsigned,
Sname varchar(50),
DOB date ,
Fees decimal(7,2));
insert into final_table values
(100,'Namrata','1998-09-09',
27384.35);
select * from final_table;
####################################
# How to comment
-- How to comment
/*How to comment
How to comment*/
-- ALTER
-- database/schema (In MySQL same)
set sql_safe_updates=0;
-- Company 
-- Acc
-- Fin
-- Logistics
/*use company;
create table acc.t1(sno int);
create table fin.t2
(name char(2));
select * from 
company.acc.t1;-- path*/
-- ALTER
desc t1;
alter table t1 
rename column col3 to sal ; 
describe t1;
alter table t1 
modify sal int;
alter table t1
add sname varchar(30);
desc t1;
alter table t1
drop rollno;
desc t1;
alter table t1 
add subject varchar(20)
after sno;-- before not in MySQL
desc t1;
alter table t1
add rollno int first;
desc t1;
select * from t1;



